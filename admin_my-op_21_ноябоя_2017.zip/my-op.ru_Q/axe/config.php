<?php

$client_id = '5920240';
// $client_id = '5907647';
$secret_key = 'K7xJ3JrSbzouXMCB8Awn';
$client_secret = 'K7xJ3JrSbzouXMCB8Awn';
$service_key = '57dfd12557dfd1255780ca0c42578584d5557df57dfd1250f1a96b18bfc63e5196a20f2';
$user_id = '105253591';
$token = 'a1da1f50196528d61bb9b91458657771a5d1b81398da638d250ad5fc2125f52aaa5bc7a87414b3164a8e9';
$token1 = '547c5b253ed4f1d2a25bf8e55c523c7a059920324d5511d3bd078fa8f9cad302c3a39ba9ab3a0d3d2be7a';

$scope = 'friends,photos,audio,video,status,wall,offline,docs,groups,email';


$iferr = '';

	// $ver = '5.63';
	// $ver = '5.30';
	$ver = '4.89';
	echo "<!-- хуй -->";
?>