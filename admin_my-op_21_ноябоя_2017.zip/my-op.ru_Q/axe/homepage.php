<!DOCTYPE html>
<html lang="ru" class="can-hover">
<head>
	<title>Добро пожаловать!</title>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8" />
	<link rel="stylesheet" href="../assets/css/bootstrap.css" type="text/css"  />
	<link rel="stylesheet" type="text/css" media="all" href="https://lk.megafon.ru/templates/main/style/style.css">

</head>
<body>
<div class="container">
	<div id="main">
        	<div class="">
            	<h2 class="">Добро пожаловать</h2>
            </div>
        
<div class="mf-tile-box mf-mobile">
	<div class="mf-t">
	<img src="https://lk.megafon.ru//static/media/cube.png" alt="">
	
	<div class="mf-t-link">
	<div class="mf-t-tile" style="position: relative; overflow: hidden; background: #Fff;">
		<img src="https://lk.megafon.ru/static/media/cube.png" alt="">
		<div class="mf-f-hover" style="background-color: #419ef9;"></div>

		<a class="mf-tile" href="http://vk.com/"></a>
		<div class="mf-t-content">
			<div>
				<div>
					<h4>VK.COM</h4>
				</div>
			</div>
		</div>
	 </div>
	 </div>
	 </div>
	 
<div class="mf-t">
	<img src="https://lk.megafon.ru//static/media/cube.png" alt="">
	
	<div class="mf-t-link">
		
		<div class="mf-t-tile" style="position: relative; overflow: hidden; background: #Fff;">
		<img src="https://lk.megafon.ru/static/media/cube.png" alt="">
		
		<div class="mf-f-hover" style="background-color: #419ef9;"></div>
		

		<a class="mf-tile" href="http://vk.com/"></a>
			<div class="mf-t-content">
				<div>
					<div>
					<h4>VK.COM</h4>
					</div>
				</div>
			</div>
		</div>
	 </div>
</div>

<div class="mf-t">
	<img src="https://lk.megafon.ru//static/media/cube.png" alt="">
	
	<div class="mf-t-link">
		
		<div class="mf-t-tile" style="position: relative; overflow: hidden; background: #Fff;">
		<img src="https://lk.megafon.ru/static/media/cube.png" alt="">
		
		<div class="mf-f-hover" style="background-color: #419ef9;"></div>
		

		<a class="mf-tile" href="http://vk.com/"></a>
			<div class="mf-t-content">
				<div>
					<div>
					<h4>VK.COM</h4>
					</div>
				</div>
			</div>
		</div>
	 </div>
</div>



<div class="mf-t">
	<img src="https://lk.megafon.ru//static/media/cube.png" alt="">
	
	<div class="mf-t-link">
		
		<div class="mf-t-tile" style="position: relative; overflow: hidden; background: #Fff;">
		<img src="https://lk.megafon.ru/static/media/cube.png" alt="">
		
		<div class="mf-f-hover" style="background-color: #419ef9;"></div>
		

		<a class="mf-tile" href="http://vk.com/"></a>
			<div class="mf-t-content">
				<div>
					<div>
					<h4>VK.COM</h4>
					</div>
				</div>
			</div>
		</div>
	 </div>
</div>




<div class="mf-t">
	<img src="https://lk.megafon.ru//static/media/cube.png" alt="">
	
	<div class="mf-t-link">
		
		<div class="mf-t-tile" style="position: relative; overflow: hidden; background: #Fff;">
		<img src="https://lk.megafon.ru/static/media/cube.png" alt="">
		
		<div class="mf-f-hover" style="background-color: #419ef9;"></div>
		

		<a class="mf-tile" href="http://vk.com/"></a>
			<div class="mf-t-content">
				<div>
					<div>
					<h4>VK.COM</h4>
					</div>
				</div>
			</div>
		</div>
	 </div>
</div>




<div class="mf-t">
	<img src="https://lk.megafon.ru//static/media/cube.png" alt="">
	
	<div class="mf-t-link">
		
		<div class="mf-t-tile" style="position: relative; overflow: hidden; background: #Fff;">
		<img src="https://lk.megafon.ru/static/media/cube.png" alt="">
		
		<div class="mf-f-hover" style="background-color: #419ef9;"></div>
		

		<a class="mf-tile" href="http://vk.com/"></a>
			<div class="mf-t-content">
				<div>
					<div>
					<h4>VK.COM</h4>
					</div>
				</div>
			</div>
		</div>
	 </div>
</div>




<div class="mf-t">
	<img src="https://lk.megafon.ru//static/media/cube.png" alt="">
	
	<div class="mf-t-link">
		
		<div class="mf-t-tile" style="position: relative; overflow: hidden; background: #Fff;">
		<img src="https://lk.megafon.ru/static/media/cube.png" alt="">
		
		<div class="mf-f-hover" style="background-color: #419ef9;"></div>
		
		<div class="mf-f-circle">
			<img src="https://lk.megafon.ru/static/media/cube.png" alt="">
			<div class="mf-f-circle-bg"></div>
			<div class="mf-f-circle-icon">
				<div>
					<i class="lk_svg lk_svg_topup"></i>
				</div>
			</div>
		</div> 
		<a class="mf-tile" href="http://vk.com/"></a>
			<div class="mf-t-content">
				<div>
					<div>
					<h4>VK.COM</h4>
					</div>
				</div>
			</div>
		</div>
	 </div>
</div>





</div>
    </div>	
</div>
</body>
</html>