<?php
$db = mysql_connect ("localhost","axe_root","nuttertools");
mysql_select_db ("reg",$db);


$client_id = '5920240';
// $client_id = '5907647';

$secret_key = 'K7xJ3JrSbzouXMCB8Awn';
$client_secret = 'K7xJ3JrSbzouXMCB8Awn';
?>