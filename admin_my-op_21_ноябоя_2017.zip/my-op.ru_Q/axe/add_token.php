<?php
session_start();
include ("bd.php");// файл bd.php должен быть в той же папке, что и все остальные, если это не так, то просто измените путь 

if (!empty($_SESSION['login']) and !empty($_SESSION['password']))
{
//если существует логин и пароль в сессиях, то проверяем, действительны ли они
$login = $_SESSION['login'];
$password = $_SESSION['password'];
$result2 = mysql_query("SELECT id FROM users WHERE login='$login' AND password='$password'",$db); 
$myrow2 = mysql_fetch_array($result2); 
if (empty($myrow2['id']))
   {
   //Если не действительны, то закрываем доступ
    exit("Вход на эту страницу разрешен только зарегистрированным пользователям!");
   }
}
else {
//Проверяем, зарегистрирован ли вошедший
exit("Вход на эту страницу разрешен только зарегистрированным пользователям!"); }


$token = @$_POST ['access_token'];




// подключаемся к базе
include ("bd.php");// файл bd.php должен быть в той же папке, что и все остальные, если это не так, то просто измените путь 

$result2 = mysql_query ("UPDATE `users` SET `access_token`='$token' WHERE `login`= '$login'");
echo "<html><head><meta http-equiv='Refresh' content='0; URL=index.php'></head><body>Токен успешно добавлены! Вы будете перемещены через 2 сек. Если не хотите ждать, то <a href='/'>нажмите сюда.</a></body></html>";


?>
</body>
</html>
